/**
 * @brief Header file for parser.c, holding function headers from this file to be used by other files in this project
 * 
 * @param name 
 * @return int 
 */
int isPid(char *name);
int parser(int argCount, char **args); 
