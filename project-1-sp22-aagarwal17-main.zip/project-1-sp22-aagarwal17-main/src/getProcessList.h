/**
 * @brief Header file for getProcessList.c, holding function headers from this file to be used by other files in this project
 * 
 */
void getAllPIDparser(char *thePID);
void allParser(int argCount, char **args);
