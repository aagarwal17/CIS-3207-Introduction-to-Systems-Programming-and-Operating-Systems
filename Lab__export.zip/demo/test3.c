#include <stdio.h>

int main() {
  char str[30];
  int j;
  for (int i = 0; i < 5; i++) {
        scanf("%s %d",str,&j);
        printf("output %s %d\n",str,j);
  }
  return 0;
}
